# EclipseMM2 (discontinued)

Hello! This is a script for [Murder Mystery 2](https://roblox.com/games/142823291/Murder-Mystery-2). The script has assassin compatiility for the gamemode inside of Murder Mystery 2. **This script has been discontinued in favor of Eclipse Hub in mid September 2021, use Eclipse Hub instead**

## Compatibility

No longer officially compatible with any executor.

## Loadstring

Eclipse MM2 is discontinued and should not be used unless necessary. **Use Eclipse Hub instead, loadstring in discord.**

## Discord

You can request a Discord Invite from the Eclipse GUI. You can only request 1 per day. You can suggest features and report bugs in the Discord server.

## Terms Of Service

**By using the script you agree to the following:**
1. Any act to deobfuscate, tamper, modify, dump, the contents of the script or API requests are not allowed. There is tamper detection in place.
2. Requesting a Discord invite will require the script to access the following:
    * Your ROBLOX Username/ID
    * A HASHED version of your IP address^
    * A HASHED version of your Exploit HWID^
    * The game you are in (Used for debugging)
    * THe script version you are using (Used for debugging)
3. Any attempt to bypass the security in place is not allowed.
4. Any act of abuse towards Eclipse API is not allowed. (This means spamming requests, trying to decrypt sensitive information)
5. If joining the Discord server, you must follow the [Discord Community Guidelines](https://discord.com/guidelines) and [Discord ToS](https://discord.com/terms).
6. If you fail to follow any of the discord server rules, you will be punished accordingly.
7. If your script version is shut down/closed, you cannot try to force it to function. This also applies to older, less secure versions.
8. This script is **not** meant to be compatible with other scripts. Bug reports of the script while another script is running will be voided.

If you agree to all of the above, then you are free to use the script.
Failure to follow the Terms of Service will result in a blacklist/ban from using the script and any other script developed by Eclipse.

^This information will be hashed, so it cannot be decrypted or read raw by the developers. This helps protect your sensitive data while providing the same security and functionallity as it normally would. If your exploit does not hash your HWID by default, your regular HWID will be sent instead, but hashed when it reaches the server.

## Credits

* API: £thanoj1#3304
* Discord Bot: £thanoj1#3304
* ToS and Github: £thanoj1#3304
* Original UI: lennard#4496 (Modified by £thanoj1#3304)

This script has been made by £thanoj1#3304 (Current/Main Dev) and Doggo#0931 (Old Dev). **£thanoj1#3304 is the ONLY current dev, all others are skids.**
(forking this project will not save your version from discontinuation, lmao)
